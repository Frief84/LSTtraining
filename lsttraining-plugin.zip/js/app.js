/**
 * Default start and end coordinates for a sample route.
 * Coordinates are in [longitude, latitude] format.
 */
const start = [13.0624, 52.4009];
const ziel = [13.0755, 52.4051];

/**
 * Initializes the OpenLayers map with a default OSM tile layer
 * and a centered view on the initial start coordinate.
 */
const map = new ol.Map({
  target: 'map',
  layers: [
    new ol.layer.Tile({ source: new ol.source.OSM() })
  ],
  view: new ol.View({
    center: ol.proj.fromLonLat([13.0624, 52.4009]),
    zoom: 12
  })
});

/**
 * Loads all rescue/fire stations (Wachen) from the backend
 * and places them on the map using styled SVG icons.
 */
fetch(LST_PLUGIN + 'get_wachen.php')
  .then(res => res.json())
  .then(data => {
    const features = data.map(wache => {
      const feature = new ol.Feature({
        geometry: new ol.geom.Point(ol.proj.fromLonLat([wache.longitude, wache.latitude])),
        name: wache.name
      });

      feature.setStyle(new ol.style.Style({
        image: new ol.style.Icon({
          src: LST_PLUGIN + 'img/wachen/' + wache.bild_datei,
          scale: 2,
          anchor: [0.5, 0.5],
          anchorXUnits: 'fraction',
          anchorYUnits: 'fraction',
          crossOrigin: 'anonymous'
        })
      }));

      return feature;
    });

    const vectorSource = new ol.source.Vector({ features });
    const vectorLayer = new ol.layer.Vector({ source: vectorSource });
    map.addLayer(vectorLayer);
  });

/**
 * Starts a vehicle movement from a given start to destination point
 * using route data provided by OpenRouteService via `get_route.php`.
 *
 * @param {string} fahrzeugPfad - Path to the vehicle image to be used as icon
 * @param {[number, number]} start - Start coordinate [lon, lat]
 * @param {[number, number]} ziel - Destination coordinate [lon, lat]
 */
function starteFahrt(fahrzeugPfad, start, ziel) {
  fetch(LST_PLUGIN + 'get_route.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ coordinates: [start, ziel] })
  })
    .then(res => res.json())
    .then(routeGeoJSON => {
      // Parse the route geometry into OpenLayers features
      const routeFeatures = new ol.format.GeoJSON().readFeatures(routeGeoJSON, {
        dataProjection: 'EPSG:4326',
        featureProjection: 'EPSG:3857'
      });

      // Draw the route as a blue line on the map
      const routeLayer = new ol.layer.Vector({
        source: new ol.source.Vector({ features: routeFeatures }),
        style: new ol.style.Style({
          stroke: new ol.style.Stroke({ color: '#007AFF', width: 4 })
        })
      });
      map.addLayer(routeLayer);

      // Extract total duration and geometry line
      const route = routeGeoJSON.features[0];
      const line = routeFeatures[0].getGeometry();
      const duration = route.properties.segments[0].duration; // in seconds

      // Add vehicle feature at start point
      const fahrzeugFeature = new ol.Feature({
        geometry: new ol.geom.Point(line.getCoordinateAt(0))
      });

      fahrzeugFeature.setStyle(new ol.style.Style({
        image: new ol.style.Icon({
          src: fahrzeugPfad,
          scale: 0.5,
          anchor: [0.5, 1],
          anchorXUnits: 'fraction',
          anchorYUnits: 'fraction',
          crossOrigin: 'anonymous'
        })
      }));

      const fahrzeugLayer = new ol.layer.Vector({
        source: new ol.source.Vector({ features: [fahrzeugFeature] })
      });
      map.addLayer(fahrzeugLayer);

      // Animate the vehicle along the route using interpolation
      let progress = 0;
      const durationMs = duration * 1000;
      const startTime = Date.now();

      /**
       * Animates the vehicle by updating its position
       * based on elapsed time and total route duration.
       */
      function animateStep() {
        const elapsed = Date.now() - startTime;
        progress = elapsed / durationMs;

        if (progress > 1) progress = 1;

        const coord = line.getCoordinateAt(progress);
        fahrzeugFeature.getGeometry().setCoordinates(coord);

        if (progress < 1) {
          requestAnimationFrame(animateStep);
        }
      }

      animateStep();
    });
}

// Start a sample vehicle route
starteFahrt('img/fahrzeug/default_RW.png', start, ziel);
