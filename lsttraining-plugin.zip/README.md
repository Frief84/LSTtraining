# LSTtraining Plugin für WordPress

Struktur siehe Projektbeschreibung.